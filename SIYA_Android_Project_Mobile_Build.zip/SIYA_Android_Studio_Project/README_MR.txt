SIYA DAILY REPORT - Android Studio Project

महत्त्वाचे:
- हा Android APK तयार करण्यासाठीचा project source आहे; तयार APK नाही.
- या रनटाइममध्ये Android SDK/Gradle उपलब्ध नसल्यामुळे APK compile करून तपासता आलेला नाही.
- HTML मध्ये आधीपासून असलेला backend URL (Render Node.js API) कायम ठेवला आहे.
- Firebase Firestore या आवृत्तीत जोडलेले नाही. Login, reports, employee management आणि approval साठी सध्याचा Node.js backend चालू असणे आवश्यक आहे.

APK तयार करण्याची पद्धत:
1. Android Studio उघडा.
2. File > Open निवडा आणि हा unzip केलेला SIYA_Android_Studio_Project folder निवडा.
3. Gradle Sync पूर्ण होऊ द्या.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
5. app/build/outputs/apk/debug/app-debug.apk येथे APK मिळेल.
6. मोबाईलवर install करताना Android ने विचारल्यास unknown apps install करण्याची परवानगी द्या.

मोबाईलमध्ये Location permission दिल्यास GPS वापरता येईल.
Photo upload साठी Camera/Gallery picker उपलब्ध आहे.
